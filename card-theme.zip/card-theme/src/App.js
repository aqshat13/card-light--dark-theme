import Heading from "./component/heading";
import Card from "./component/card";
const App =()=>{
    return(<div>
    
    {Heading("Hello programmer")}
    <Card title='full-stack' subtitle='akshat' disc='dubey'/>
    <Card title='data analyst' subtitle='akshat' disc='dubey'/>
    </div>)
  };

  export default App ;
