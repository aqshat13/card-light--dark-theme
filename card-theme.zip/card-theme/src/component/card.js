import "./card.css"
import {useState} from 'react';

const Card=(props)=>{
  const [dark, setDark] = useState(true);

    return(
    <div className="card-wrapper"
     style={{ 
        backgroundColor:dark ? '#181818':'#5CB8E4',
        color:dark ?'#5CB8E4':  '#181818' }}  
    >
       <div className='card-header'>
       <h1>{props.title}</h1>
       </div>
       <div className='card-body'>
        <p>{props.subtitle}</p>
        <p>{props.disc}</p>
        
       </div>
       <button style={{ 
        backgroundColor: dark ? '#181818':'#5CB8E4' ,
        color:dark ?'#5CB8E4':'#181818' ,
        border: dark ?'5px solid #5CB8E4':'5px solid #181818',}
        } 
        onClick={()=>{setDark(!dark)}} 
    >{dark ? 'Light Mode':'Dark Mode'}</button>
    </div>
    )
};

export default Card;
